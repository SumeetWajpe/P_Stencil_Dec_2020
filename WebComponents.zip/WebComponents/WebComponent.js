//Define the web component
class Helloworld extends HTMLElement{
    constructor(){
        super();
        console.log('Hello from Web Component !');
    }
}
//Registering a web component
customElements.define('uc-helloworld',Helloworld);