export class CourseModel{  
    constructor(public name:string,public price:number ){
       
    }
}