import { Component,h, Prop } from "@stencil/core";

@Component({
    tag:'uc-course'
})
export class UcCourse{
    @Prop() coursedetails:any;  
    render(){
        return <div>
                <h4>{this.coursedetails.name}</h4>
                <strong>{this.coursedetails.price}</strong>
        </div> ;
    }
}