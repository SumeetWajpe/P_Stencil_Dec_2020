import { Component, h } from '@stencil/core';
import { CourseModel } from '../models/course.model';

@Component({
  tag: 'uc-app',
})
export class UcApp {
  courses: CourseModel[] = [new CourseModel('VueJS', 5000), 
  { name: 'WebComponents', price: 6000 },
   { name: 'Angular', price: 6000 }];

  render() {
    var listofcourses = this.courses.map(c=><uc-course coursedetails={c}></uc-course>)
    return (
      <div>        
        {listofcourses}        
      </div>
    );
  }
}
