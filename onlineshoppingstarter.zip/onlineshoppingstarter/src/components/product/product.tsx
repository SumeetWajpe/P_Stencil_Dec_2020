import { Component, h, Prop } from '@stencil/core';


@Component({
    tag: 'uc-product'
})
export class Product {
    @Prop() productdetails:any;      
   
    render() {    
        return (
          <div>
            <div>
              <h1>{this.productdetails.title}</h1>
              <img src={this.productdetails.ImageUrl} height="100"  width="100"
              />
              <br />
              <strong>Price : </strong> {this.productdetails.price} <br />
              <strong>Quantity : </strong> {this.productdetails.quantity}{" "}
              <br />
              <strong>Rating : </strong> {this.productdetails.rating} <br />
              <button >                
                {this.productdetails.likes}
              </button> 
              <button >
                  Delete
                </button>             
              <br />
            </div>
          </div>
        );
      }
}