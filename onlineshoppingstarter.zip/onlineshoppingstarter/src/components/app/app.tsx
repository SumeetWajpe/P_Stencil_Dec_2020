import { Component, h } from '@stencil/core';

@Component({
    tag: 'uc-app'
})
export class app {
    
    render() {
        return (           
             <shopping-cart></shopping-cart>
        );
    }
}