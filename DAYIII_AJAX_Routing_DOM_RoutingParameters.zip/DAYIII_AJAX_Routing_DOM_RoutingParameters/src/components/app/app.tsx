import { Component, h } from '@stencil/core';

@Component({
  tag: 'uc-app',
})
export class app {
  render() {
    return ( 
      <stencil-router>
          <stencil-route-switch>
              <stencil-route url="/" component="shopping-cart" exact></stencil-route>
              <stencil-route url="/posts" component="uc-posts" ></stencil-route>
              <stencil-route url="/postdetails/:id" component="uc-post-details" ></stencil-route>
              <stencil-route url="/chromatogram" component="chromatogram-component" ></stencil-route>
              <stencil-route url="/getpostbyid" component="uc-get-post-by-id" ></stencil-route>
          </stencil-route-switch>
      </stencil-router>
    );
  }
}


{/*  <div>
        <shopping-cart></shopping-cart>
        <uc-posts></uc-posts>
        <uc-get-post-by-id></uc-get-post-by-id>
        <uc-get-post-by-id-query-selector></uc-get-post-by-id-query-selector>
        <uc-get-post-by-id-shadow-dom></uc-get-post-by-id-shadow-dom>
        <uc-get-post-by-id-target></uc-get-post-by-id-target> 
      </div>*/}