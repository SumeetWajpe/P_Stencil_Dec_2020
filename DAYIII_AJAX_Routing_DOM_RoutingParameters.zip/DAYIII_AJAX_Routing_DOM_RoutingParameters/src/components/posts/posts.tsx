import { Component, h, Host, State } from '@stencil/core';

@Component({
    tag: 'uc-posts'
})
export class posts {

    @State() allPosts:any = []; // use strongly typed model (PostModel)
    componentWillLoad(){
        console.log('componentWillLoad..')
        fetch('https://jsonplaceholder.typicode.com/posts').
        then(res=>res.json())
        .then(postsData=> this.allPosts = postsData)
        .catch(err=>console.log(err))
    }
    
    render() {
        console.log('Render..')
        let allPostsToBeCreated = this.allPosts.map(p=><li><stencil-route-link url={`/postdetails/${p.id}`}>{p.title}</stencil-route-link></li>)
        return (
            <Host>
                <h1>All Posts </h1>
              <ul>
                  {allPostsToBeCreated}
              </ul>
            </Host>
              
              );
    }
}