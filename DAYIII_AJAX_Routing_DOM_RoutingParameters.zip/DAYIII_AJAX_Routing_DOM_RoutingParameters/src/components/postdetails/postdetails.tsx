import { Component, h, Host, Prop, State } from '@stencil/core';
import { MatchResults, RouterHistory } from '@stencil/router';

@Component({
  tag: 'uc-post-details',
})
export class postdetails {
    @Prop() match:MatchResults;
    @State() thePost:any = {}; // use strongly typed model (PostModel)
    @Prop() history:RouterHistory;
    componentWillLoad(){
     
        fetch(`https://jsonplaceholder.typicode.com/posts/${this.match.params.id}`).
        then(res=>res.json())
        .then(thePost=> this.thePost = thePost)
        .catch(err=>console.log(err))
    }
  render() {

    return ( 
        <Host>
        <h1>Post Details for {this.match.params.id}</h1>
        <div>
            <p><strong> Id : </strong> {this.thePost.id}</p>
            <p><strong> UserId : </strong> {this.thePost.userId}</p>
            <p> <strong> Title :  </strong>{this.thePost.title}</p>
            <p> <strong>Body : </strong>{this.thePost.body}</p>
            <button class="btn btn-success" onClick={()=>this.history.goBack()}>
                Back to Posts
            </button>
        </div>
        </Host>
    );
  }
}


