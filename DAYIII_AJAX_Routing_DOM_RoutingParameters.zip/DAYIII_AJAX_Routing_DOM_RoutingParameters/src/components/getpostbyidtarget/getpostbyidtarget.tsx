import { Component, h, State } from '@stencil/core';

@Component({
  tag: 'uc-get-post-by-id-target',
})
export class getpostbyidtarget {
   @State() thePostId:number;
    @State() thePost:any={};
    @State() ispostInputValid:boolean = false;
    
    getPostById(e:Event){
        e.preventDefault(); 
        fetch(`https://jsonplaceholder.typicode.com/posts/${this.thePostId}`).
        then(res=>res.json()).
        then(thePost=>this.thePost = thePost);

    }

    onUserInput(e:Event){
        let theInput = (e.target as HTMLInputElement).value;
        if(theInput.trim() !== ''){
            this.ispostInputValid = true;
        }
        else{
            this.ispostInputValid = false;
        }
        this.thePostId = +theInput; // convert to a number 
        
    }
  render() {
      let msg;
      if(!this.ispostInputValid){
        msg = "The Id is required !";
      }
    return (
      [<form onSubmit={this.getPostById.bind(this)}>
        <div class="postContainer">
          Enter Post Id : <input type="text" onInput={this.onUserInput.bind(this)}  />
          <button type="submit" disabled={!this.ispostInputValid}>Get Post</button> 
          <p>
              {this.thePost.title}
          </p>
        </div>
      </form>,
    <p>{msg}</p>  
    ]
    );
  }
}
