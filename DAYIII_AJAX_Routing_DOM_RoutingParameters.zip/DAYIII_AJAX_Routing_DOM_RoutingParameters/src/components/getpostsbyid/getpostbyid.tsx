import { Component, h, State } from '@stencil/core';

@Component({
  tag: 'uc-get-post-by-id',
})
export class getpostbyid {
    postInput:HTMLInputElement;
    @State() thePost:any={};
    getPostById(e:Event){
        e.preventDefault();        
        let postId = this.postInput.value;
        fetch(`https://jsonplaceholder.typicode.com/posts/${postId}`).
        then(res=>res.json()).
        then(thePost=>this.thePost = thePost);

    }
  render() {
    return (
      <form onSubmit={this.getPostById.bind(this)}>
        <div class="postContainer">
          Enter Post Id : <input type="text" 
          ref={element=> this.postInput = element} />
          <button type="submit">Get Post</button> 
          <p>
              {this.thePost.title}
          </p>
        </div>
      </form>
    );
  }
}
