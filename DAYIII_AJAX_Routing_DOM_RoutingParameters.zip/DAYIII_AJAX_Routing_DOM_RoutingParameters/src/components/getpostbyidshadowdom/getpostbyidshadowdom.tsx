import { Component, Element, h, State } from '@stencil/core';

@Component({
  tag: 'uc-get-post-by-id-shadow-dom',
  shadow:true
})
export class getpostbyidshadowdom {
    @Element() el:HTMLElement;
    @State() thePost:any={};
    getPostById(e:Event){
        e.preventDefault();        
        let postId = (this.el.shadowRoot.querySelector('#txtPostId') as HTMLInputElement).value;
        console.log(postId);
        fetch(`https://jsonplaceholder.typicode.com/posts/${postId}`).
        then(res=>res.json()).
        then(thePost=>this.thePost = thePost);

        // let svgString = '<svg width="500" height="400" xmlns="http://www.w3.org/2000/svg"><!-- Created with Method Draw - http://github.com/duopixel/Method-Draw/ --><g><title>background</title><rect fill="#fff" id="canvas_background" height="402" width="502" y="-1" x="-1"/><g display="none" overflow="visible" y="0" x="0" height="100%" width="100%" id="canvasGrid"><rect fill="url(#gridpattern)" stroke-width="0" y="0" x="0" height="100%" width="100%"/></g></g><g><title>Layer 1</title><path id="svg_1" d="m118,242l64,-153l63,157c0,0 45,-71 49,-68c4,3 11,146 12,146c1,0 -173,-7 -173,-7c0,0 -61,-72 -61,-72c0,0 110,-156 46,-3z" fill-opacity="0.7" stroke-width="2" stroke="#995757" fill="#995757"/></g></svg>';

        // let theDiv = (this.el.shadowRoot.querySelector('#targetDiv') as HTMLDivElement);
        // theDiv.innerHTML = svgString;
    }
  render() {
    return (
      <form onSubmit={this.getPostById.bind(this)}>
          <div id="targetDiv">
          </div>
        <div class="postContainer" >
          Enter Post Id : <input type="text" id="txtPostId" />
          <button type="submit">Get Post</button> 
          <p>
              {this.thePost.title}
          </p>
        </div>

        
      </form>
    );
  }
}
