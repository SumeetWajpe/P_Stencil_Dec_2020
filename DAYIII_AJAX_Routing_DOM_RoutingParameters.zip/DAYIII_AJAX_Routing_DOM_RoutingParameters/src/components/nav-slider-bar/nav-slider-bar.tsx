import { Component, h, Prop} from '@stencil/core';

@Component({
    tag: 'nav-slider-bar',
    styleUrl:'nav-slider-bar.css',
    shadow:true
  })
export class NavSliderBar { 
    @Prop({reflect:true}) title:string;
    @Prop({reflect:true}) opened:boolean=false;

    closeSliderNav(){
        this.opened = false;
    }
  render() {   
    return (
      <aside>
          <header>
                <h3>{this.title}</h3>
        <button onClick={this.closeSliderNav.bind(this)}>
              X
          </button> 
          </header>
          <slot>
              No actions here
          </slot>
      </aside>
    );
  }
}

