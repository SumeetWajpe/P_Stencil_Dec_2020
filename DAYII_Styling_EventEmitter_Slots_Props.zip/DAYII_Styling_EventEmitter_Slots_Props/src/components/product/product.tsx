import { Component, EventEmitter, h, Prop, State,Event } from '@stencil/core';


@Component({
    tag: 'uc-product',
    styleUrl:'product.css'
})
export class Product {
    @Prop() productdetails:any;      
    @State() currLikes:number;
    @Event({
      eventName:'deleteProduct',
      // composed:false  // restricting in a showDOM scope
      //bubbles:false
    }) deleteProduct:EventEmitter<number>;

    constructor(){
      this.currLikes = this.productdetails.likes;
    }
    IncrementLikes(){
      console.log('U Clicked !');
      //this.productdetails.likes++; // immutable
      this.currLikes++; 
    }
    render() {    
     // console.log('Render..')
        return (
          <div class="col-md">
            <div class="productitem">
              <h1>{this.productdetails.title}</h1>
              <img src={this.productdetails.ImageUrl} height="100"  width="100"
              />
              <br />
              <strong>Price : </strong> {this.productdetails.price} <br />
              <strong>Quantity : </strong> {this.productdetails.quantity}{" "}
              <br />
              <strong>Rating : </strong> {this.productdetails.rating} <br />
              {/* <button onClick={this.IncrementLikes.bind(this)} >                
                {this.productdetails.likes}
              </button>  */}

            <button class="btn btn-primary"
             onClick={()=>this.IncrementLikes()} >                
                {this.currLikes}
              </button> 

              <button class="btn btn-danger"
              onClick={()=>this.deleteProduct.emit(this.productdetails.id)} >
                  Delete
                </button>             
              <br />
            </div>
          </div>
        );
      }
}